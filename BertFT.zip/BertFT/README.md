# Project Overview

This project utilizes PyTorch and Hugging Face's Transformers library to fine-tune a BERT model for masked language modeling (MLM) using custom dataset inputs. 

## Requirements

Before running the code, ensure the following steps are completed:

1. **Install Required Packages**:

   - PyTorch
   - Hugging Face Transformers
   - Matplotlib
   - NLTK
   - Pandas
   - Scikit-learn

   You can install these packages using pip:

   ```bash
   pip install torch transformers matplotlib nltk pandas scikit-learn
   ```

2. **Download Pre-trained BERT Model**:

   - Download the pre-trained BERT model and tokenizer (`bert-base-uncased`) using Hugging Face's Transformers library:

   ```python
   from transformers import BertForMaskedLM, BertTokenizer
   
   model = BertForMaskedLM.from_pretrained('bert-base-uncased')
   tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
   ```

3. **Prepare Dataset**:
   - Ensure you have a dataset in CSV format containing text data for training and testing the MLM model. This CSV should include columns for `summary` and `description`.
   - Alternatively, you can modify the code to work with your custom data format by adapting the `MLMDataset` class and data preprocessing steps in `train_bert.py`.

## How to Run the Code

To run the code and train the BERT model for MLM, follow these steps:

1. **Prepare Data**:

   - Organize your dataset into train and test CSV files.
   - Update the `config.train_data_dir` and `config.test_data_dir` variables in `config.py` to point to these CSV files.

2. **Execute the Script**:

   - Run the `main()` function in the `train_bert.py` script:

   ```bash
   python train_bert.py
   ```

   This will start the training process.

## Best Model

Once the training is complete, the best model checkpoint will be saved automatically based on the evaluation loss. You can find the best model checkpoint in the specified output directory (`config.ptm`). The best model will be located in the `bestModel` subfolder within this directory.