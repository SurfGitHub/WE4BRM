import torch

device = "cuda" if torch.cuda.is_available() else "cpu"

seed = 42
reproducibility = True

max_len = 500
batch_size = 8
num_epoch = 2250
lr = 1e-7
ptm = '../data/bertFTModel/'

data_dir = '../data/initData/'
train_data_dir = ''
test_data_dir = ''

loss_name = "loss"
loss_name_val = "validation loss"
lr_p = "lr"