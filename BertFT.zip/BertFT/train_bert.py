import torch
from torch.utils.data import DataLoader, Dataset
from transformers import BertTokenizer, BertForNextSentencePrediction,BertForMaskedLM, AdamW, get_linear_schedule_with_warmup
from transformers import TrainingArguments, Trainer,DataCollatorForLanguageModeling,TrainerCallback
import logging
from tqdm.auto import tqdm
import matplotlib.pyplot as plt
import json
from torch.utils.tensorboard import SummaryWriter
import config
import pandas as pd
import os
from torch.cuda.amp import GradScaler,autocast
import nltk
from sklearn.model_selection import RandomizedSearchCV
tknizer = nltk.data.load('tokenizers/punkt/english.pickle')
max_len = config.max_len
def chunker(data, length):
    return [data[x:x + length] for x in range(0, len(data), length)]

def dealSentence(content, tknizer):
    text = []
    for t in content:
        sents = tknizer.tokenize(t)
        ss = []
        for s in sents:
            s = s.split()
            ws = []
            for w in s:
                if len(w) >= 64:
                    continue
                ws.append(w)
            s = ws
            if len(s) > max_len:
                slist = chunker(s, max_len)
                for sl in slist:
                    ss.append(' '.join(sl))
            else:
                ss.append(' '.join(s))
        sents = ss
        text.append('\n'.join(sents))
        return text


class MLMDataset(Dataset):
    def __init__(self, data_dir,tokenizer):
        self.data_dir = data_dir
        self.tokenizer = tokenizer

        # self.data = pd.read_csv(data_dir)[:500]
        self.data = pd.read_csv(data_dir)
        self.data.dropna(inplace=True)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        data_row = self.data.iloc[idx]

        # text = self.texts[idx]
        text = data_row['summary']+data_row['description']
        textlist = text.strip().replace('\n','').replace('\r','').split('.')
        format_text = dealSentence(textlist, tknizer)
        text = '\n\n'.join(format_text)
        inputs = self.tokenizer.encode_plus(text,add_special_tokens=True,padding='max_length',truncation=True,max_length=512)
        input_ids = torch.tensor(inputs['input_ids'])
        attention_mask = torch.tensor(inputs['attention_mask'])
        labels = input_ids.clone()
        labels[labels == 0] = -100
        return {'input_ids':input_ids,'attention_mask':attention_mask,'labels':labels}

class CustomCallback(TrainerCallback):

    def __init__(self, trainer):
        super().__init__()
        self._trainer = trainer

    def on_step_end(self,args,state,control, **kwargs):
        step = self._trainer.state.global_step
        epoch = self._trainer.state.epoch
        # print('Im here!',step)
        if step < 11:
            if step % 2 == 0:
                save_checkpoint(args, self._trainer, epoch, step)
        else:
            if step < 500:
                if step % 100 == 0:
                    save_checkpoint(args, self._trainer, epoch, step)
            if step > 50000:
                if step % 1000 == 0:
                    save_checkpoint(args, self._trainer, epoch, step)
        # else:
        #     if step % 5000 == 0:
        #         save_checkpoint(args, self._trainer, epoch, step)
        # if step < 55000:
        #     if step % 1000 == 0:
        #         save_checkpoint(args, self._trainer, epoch, step)
        # else:
        #     if step % 1000 == 0:
        #         save_checkpoint(args, self._trainer, epoch, step)


def init_seed(seed, reproducibility):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if reproducibility:
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
    else:
        torch.backends.cudnn.benchmark = True
        torch.backends.cudnn.deterministic = False


def save_checkpoint(args,trainer,epoch,step):
    checkpoint_folder = os.path.join(args.output_dir,f"testModel/test-{step}")
    os.makedirs(checkpoint_folder,exist_ok=True)
    trainer.save_model(checkpoint_folder)
    trainer_state = trainer.state.__dict__
    with open(os.path.join(checkpoint_folder,"trainer_state.json"),'w') as fp:
        json.dump(trainer_state,fp,indent=2)

def train(writer):
    device = config.device

    model = BertForMaskedLM.from_pretrained('bert-base-uncased')
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
    model.to(device)


    train_data_dir = os.path.join(config.data_dir, config.train_data_dir)
    test_data_dir = os.path.join(config.data_dir, config.test_data_dir)

    trainDataset = MLMDataset(train_data_dir,tokenizer)
    testDataset = MLMDataset(test_data_dir,tokenizer)

    data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=True, mlm_probability=0.15)

    training_args = TrainingArguments(
        output_dir=config.ptm,  # output directory
        num_train_epochs=config.num_epoch,  # total number of training epochs
        per_device_train_batch_size=8,  # batch size per device during training
        warmup_steps=1000,  # number of warmup steps for learning rate scheduler
        weight_decay=0.01,  # strength of weight decay
        logging_dir='./logs',  # directory for storing logs
        logging_steps=5,  # log every n steps
        load_best_model_at_end=True,  # save/checkpoint the best model at the end of training
        prediction_loss_only=True,
        metric_for_best_model='eval_loss',  # use loss to evaluate the best model
        save_total_limit=5,  # limit the total amount of checkpoints
        gradient_accumulation_steps=2,
        # number of gradient accumulation steps before performing a backward/update pass.
        per_device_eval_batch_size=8,  # batch size for evaluation
        evaluation_strategy='steps',  # evaluation strategy to adopt during training
        save_strategy='steps',  # checkpoint save strategy
        # early_stopping_patience=3,    # Stop training after 3 evaluations without improvement in eval_loss
        # early_stopping_threshold=0.01, # Minimum improvement in eval_loss to be considered as improvement
        eval_steps=1000,  # evaluation step.
        save_steps=1000,  # save checkpoint every n steps.
        learning_rate=config.lr,  # learning rate

    )

    model.to(device)

    trainer = Trainer(
        model=model,  # the instantiated Transformers model to be trained
        args=training_args,  # training arguments, defined above
        train_dataset=trainDataset,  # training dataset
        eval_dataset=testDataset,
        data_collator=data_collator,
    )
    trainer.add_callback(CustomCallback(trainer))

    trainer.train()
    trainer.save_model(f'' + config.ptm+'/bestModel')

def main():
    writer = SummaryWriter('./logs')
    init_seed(config.seed, config.reproducibility)
    train(writer)
    writer.close()
    random_search = RandomizedSearchCV(estimator=rf_classifier, param_distributions=param_dist, n_iter=100, cv=5, n_jobs=-1, random_state=42)



if __name__ == '__main__':
    main()