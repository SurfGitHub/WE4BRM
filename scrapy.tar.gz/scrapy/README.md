## Project Overview

This Scrapy project contains a Spider designed to crawl bug reports. It uses Eclipse Bugzilla system as an example.

## Usage

1. Ensure that Scrapy and project dependencies are installed.

   ```
   pip install scrapy
   ```

2. Modify the **URL** source for crawling defects according to your actual needs, and adjust the extraction method and **XPath** expressions for the fields as needed.

3. Execute the following command to start the Spider and save the results to a file:

   ```
   scrapy crawl test -o <filename>.<extension>
   ```

## Example

```
scrapy crawl test -o eclipse.xml
```

