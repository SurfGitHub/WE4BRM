# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class ScrapytestItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    id = scrapy.Field()
    create_time = scrapy.Field()
    summary = scrapy.Field()
    delta_time = scrapy.Field()
    reporter_accessible = scrapy.Field()
    cclist_accessible = scrapy.Field()
    classification_id = scrapy.Field()
    classification = scrapy.Field()
    product = scrapy.Field()
    component = scrapy.Field()
    version = scrapy.Field()
    rep_platform = scrapy.Field()
    op_sys = scrapy.Field()
    bug_status = scrapy.Field()
    resolution = scrapy.Field()
    bug_file_loc = scrapy.Field()
    status_whiteboard = scrapy.Field()
    keywords = scrapy.Field()
    see_also = scrapy.Field()
    priority = scrapy.Field()
    bug_severity = scrapy.Field()
    target_milestone = scrapy.Field()
    everconfirmed = scrapy.Field()
    reporter = scrapy.Field()
    assigned_to = scrapy.Field()
    cc = scrapy.Field()
    votes = scrapy.Field()
    comment_sort_order = scrapy.Field()
    comments = scrapy.Field()
    commenter = scrapy.Field()
    comment_id = scrapy.Field()
    comment_time = scrapy.Field()
    dup_id = scrapy.Field()
    qa_contact = scrapy.Field()
    description = scrapy.Field()
    attachments = scrapy.Field()
