import pymysql.cursors
from scrapy.utils.project import get_project_settings
from twisted.enterprise import adbapi


class DBHelper():
    def __init__(self):
        settings = get_project_settings()

        dbparams = dict(
            host=settings['MYSQL_HOST'],
            db=settings['MYSQL_DBNAME'],
            user=settings['MYSQL_USER'],
            passwd=settings['MYSQL_PASSWD'],
            charset='utf8',
            cursorclass=pymysql.cursors.DictCursor
        )
        dbpool = adbapi.ConnectionPool('pymysql', **dbparams)

        self.dbpool = dbpool

    def connect(self):
        return self.dbpool

    def insert(self, item):
        sql = "insert into eclipse_xml(bug_id, creation_ts, short_desc, delta_ts, reporter_accessible, " \
              "cclist_accessible, classification_id, classification, product, component, version, rep_platform, " \
              "op_sys, bug_status, resolution, bug_file_loc, status_whiteboard, keywords, priority, bug_severity, " \
              "targer_milestone, everconfirmed, reporter, assigned_to, votes, comment_sort_order, comment, commenter, " \
              "comment_id, comment_time, dup_id, qa_contact, cc, see_also) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s," \
              "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) "
        query = self.dbpool.runInteraction(self._conditional_insert, sql, item)
        query.addErrback(self._handle_error)

        return item

    def _conditional_insert(self, tx, sql, item):
        params = (item['id'], item['create_time'], item['summary'], item['delta_time'], item['reporter_accessible'], item['cclist_accessible'],
                  item['classification_id'], item['classification'], item['product'], item['component'], item['version'],
                  item['rep_platform'], item['op_sys'], item['bug_status'], item['resolution'], item['bug_file_loc'],
                  item['status_whiteboard'], item['keywords'], item['priority'], item['bug_severity'],
                  item['target_milestone'], item['everconfirmed'], item['reporter'], item['assigned_to'],
                  item['votes'], item['comment_sort_order'], item['comment'], item['commenter'], item['comment_id'], item['comment_time'],
                  item['dup_id'], item['qa_contact'], item['cc'], item['see_also'])
        tx.execute(sql, params)

    def _handle_error(self, failure):
        if failure:
            print('--------------database operation exception!!-----------------')
            print(failure)
