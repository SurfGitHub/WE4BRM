import json
import re

import scrapy

from ..items import ScrapytestItem


class TestSpider(scrapy.Spider):
    name = 'test'
    allowed_domains = ['https://bugs.eclipse.org/bugs/show_bug.cgi']
    # start_urls = ['https://bugs.eclipse.org/bugs/show_bug.cgi?ctype=xml&id=785669']

# 259845
# 546989
# you can specify the bugId range for your need.
    def start_requests(self):
        for id in range(550299, 546989, -1):
            url = 'https://bugs.eclipse.org/bugs/show_bug.cgi?ctype=xml&id={}'.format(id)
            yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):
        item = ScrapytestItem()
        # print(response.text)
        error = response.xpath('/bugzilla/bug/@error').get()
        print(error)
        if error is None:

            item['id'] = response.xpath('//bugzilla/bug/bug_id/text()').get()
            item['create_time'] = response.xpath('//bugzilla/bug/creation_ts/text()').get()
            item['summary'] = response.xpath('//short_desc/text()').get()
            item['delta_time'] = response.xpath('//delta_ts/text()').get()

            item['reporter_accessible'] = response.xpath('//reporter_accessible/text()').get()
            item['cclist_accessible'] = response.xpath('//cclist_accessible/text()').get()
            item['classification_id'] = response.xpath('//classification_id/text()').get()
            item['classification'] = response.xpath('//classification/text()').get()
            item['product'] = response.xpath('//product/text()').get()

            item['component'] = response.xpath('//component/text()').get()

            item['version'] = response.xpath('//version/text()').get()

            item['rep_platform'] = response.xpath('//rep_platform/text()').get()

            item['op_sys'] = response.xpath('//op_sys/text()').get()

            item['bug_status'] = response.xpath('//bug_status/text()').get()

            item['resolution'] = response.xpath('//resolution/text()').get()

            item['bug_file_loc'] = response.xpath('//bug_file_loc/text()').get()

            item['status_whiteboard'] = response.xpath('//status_whiteboard/text()').get()

            item['keywords'] = response.xpath('//keywords/text()').get()

            item['see_also'] = response.xpath('//see_also/text()').extract()

            item['priority'] = response.xpath('//priority/text()').get()

            item['bug_severity'] = response.xpath('//bug_severity/text()').get()

            item['target_milestone'] = response.xpath('//target_milestone/text()').get()

            item['everconfirmed'] = response.xpath('//everconfirmed/text()').get()

            item['reporter'] = response.xpath('//reporter/@name').get()

            item['assigned_to'] = response.xpath('//assigned_to/@name').get()

            item['cc'] = response.xpath('//cc/text()').extract()

            item['votes'] = response.xpath('//votes/text()').get()

            # item['comment_sort_order'] = response.xpath('//comment_sort_order/text()').get()

            comments = response.xpath('//long_desc/thetext/text()').extract()
            # print(len(comments))
            commenter = response.xpath('//long_desc/who/@name').extract()
            # print(len(commenter))
            ids = response.xpath('//long_desc/commentid/text()').extract()
            # print(len(ids))
            times = response.xpath('//long_desc/bug_when/text()').extract()
            # print(len(times))

            c = re.compile('<(\S*?)[^>]*>.*?|<.*? />')

            if len(comments) > 0:
                item['description'] = c.sub('', comments[0])
            else:
                item['description'] = ''

            item['comments'] = []
            for index in range(1, len(comments)):
                d = {}
                d['commentid'] = ids[index]
                d['comment'] = c.sub('', comments[index])
                d['commenter'] = commenter[index]
                d['time'] = times[index]
                item['comments'].append(d)

            item['dup_id'] = response.xpath('//dup_id/text()').get()

            item['qa_contact'] = response.xpath('//qa_contact/@name').get()

            item['attachments'] = []
            obsolete = response.xpath('/bugzilla/bug/attachment/@isobsolete').extract()
            patch = response.xpath('/bugzilla/bug/attachment/@ispatch').extract()
            date = response.xpath('/bugzilla/bug/attachment/date/text()').extract()
            delta_ts = response.xpath('/bugzilla/bug/attachment/delta_ts/text()').extract()
            desc = response.xpath('/bugzilla/bug/attachment/desc/text()').extract()
            filename = response.xpath('/bugzilla/bug/attachment/filename/text()').extract()
            type = response.xpath('/bugzilla/bug/attachment/type/text()').extract()
            size = response.xpath('/bugzilla/bug/attachment/size/text()').extract()
            author = response.xpath('/bugzilla/bug/attachment/attacher/text()').extract()

            for index in range(len(obsolete)):
                d = {}
                d['isobsolete'] = obsolete[index]
                d['ispatch'] = patch[index]
                d['date'] = date[index]
                d['delta_ts'] = delta_ts[index]
                d['desc'] = desc[index]
                d['filename'] = filename[index]
                d['type'] = type[index]
                d['size'] = size[index]
                d['attacher'] = author[index]
                item['attachments'].append(d)

            yield item
